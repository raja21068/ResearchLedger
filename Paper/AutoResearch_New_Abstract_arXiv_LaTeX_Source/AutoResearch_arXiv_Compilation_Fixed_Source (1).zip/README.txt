ARXIV SELF-CONTAINED SOURCE (pdflatex)
Compile main.tex with pdflatex twice. No biber or bibtex is needed.
references.tex is a prebuilt numeric reference list; ref.bib is retained as editable source.
supplement.pdf contains all 14 pages of the supplementary material, extracted from
previously compiled combined manuscript. It is appended by pdfpages.
Do not upload previously compiled PDFs as separate main document inputs.
No npj branding is present.
Warning: the new general-AutoResearch abstract makes benchmark claims that may not be
documented in the transactional-revision-focused main article. Verify before posting.
