# npj Artificial Intelligence — publication-style preview

The article is formatted to **resemble the two-column appearance** of the sample published npj Artificial Intelligence paper provided by the user. This is an **unpublished manuscript** and is not a publisher-produced proof or the official production template.

## Files
- `main.tex`, `main.pdf`: two-column manuscript with full-width title/abstract, journal-style headings, numbered references and full-width figures/tables.
- `supplement.tex`, `supplement.pdf`: standalone supplementary information, preserved as one-column PDF.
- `ref.bib`, `figs/`: references and figure sources.
- `SUBMISSION_METADATA.md`: journal-facing authorship metadata and required approvals.
- `AUTHOR_CONTACTS_DO_NOT_SUBMIT.md`: additional user-supplied identifiers/social contacts, not for manuscript publication.
- `FORMATTING_AND_SUBMISSION_NOTES.md`: conversion detail and outstanding submission checks.

## Rebuild PDFs

Requires TeX Live with `latexmk`, `biber`, `biblatex` with Nature bibliography support and newtx fonts.

```bash
latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
latexmk -pdf -interaction=nonstopmode -halt-on-error supplement.tex
```

## Important
Nature Portfolio production templates and DOI/citation metadata are assigned by the journal. This preview deliberately avoids invented publisher identifiers and indicates that it is unpublished. Before submission, use the journal's current author instructions and obtain final authorship approval.
