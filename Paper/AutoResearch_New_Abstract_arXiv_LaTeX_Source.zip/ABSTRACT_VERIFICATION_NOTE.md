# Abstract replacement / scientific consistency check

The abstract in `main.tex` and `arxiv_combined.tex` was replaced with the author-provided text, correcting pasted spacing and rendering `LaTeX` as a command. The repository link was retained.

**Important: the supplied abstract is not supported by the body of the current manuscript.** Specifically, HumanEval, MBPP, the SciCode subset, citation-validation benchmarks, comparative execution success, baseline superiority, and end-to-end workflow stress-testing outcomes are not documented as evaluated results in the current Transactional Research Ledger manuscript. Its Results section instead reports synthetic revision fixtures (815/815), 13 historical scientific-software revisions, transactional fault injection, and related local checks.

Do not submit or publicly disseminate this version as empirical validation of the added benchmark claims until the corresponding methods, comparisons, data, results and reproducibility artifacts are incorporated and independently checked. No new experiments were run for this abstract update. The manuscript body and supplementary information were left unchanged.
