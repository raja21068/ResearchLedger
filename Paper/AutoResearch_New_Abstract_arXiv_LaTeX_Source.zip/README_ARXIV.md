# AutoResearch arXiv package — abstract updated

- `arxiv_combined.tex` compiles the main paper and appends `supplement.pdf` (full 14-page supplement).
- `main.tex` is the main paper alone.
- `supplement.tex` is the separately compilable single-column supplement.
- `ref.bib` and `figs/` contain the bibliography and figure sources.

The title is *AutoResearch: A Multi-Agent Framework for Reliable Research Workflow Automation*. The new abstract is author-supplied and reformatted, not verified. **Read `ABSTRACT_VERIFICATION_NOTE.md` before submission.**

Code repository: https://github.com/raja21068/ResearchLedger
