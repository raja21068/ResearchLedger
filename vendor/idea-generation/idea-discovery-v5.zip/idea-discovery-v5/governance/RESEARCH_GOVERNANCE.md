# V4 Research Governance

V4 follows a fail-closed research policy:

1. **Traceability:** every idea must retain a GAP-ID and every gap must retain source evidence.
2. **Ground before generating:** idea generation is blocked by default when the discovery pool is below the configured minimum.
3. **Problem selection before solution design:** Level 1/2 solved problems are switched away from rather than polished.
4. **Quote-or-zero:** solution-level evidence must be traceable to retrieved abstract text; unsupported evidence is discarded.
5. **Three-persona diversity:** idea evolution must expose candidates to novelty, feasibility, and scientific-value pressures before adversarial review.
6. **Destructive novelty search:** the novelty search is explicitly tasked with finding work that invalidates the idea's novelty.
7. **Closest-competitor reasoning:** novelty requires an intellectual contribution beyond feature-count differences.
8. **Hostile reviewer test:** fatal pre-coding flaws must trigger revision, pivot, or kill.
9. **Revision invalidates prior passes:** every material revision restarts the attack loop with fresh search.
10. **Relative ranking is downstream:** ELO can rank only GREENLIGHT survivors.
11. **Negative-result value:** ideas should remain scientifically informative when the primary hypothesis fails.
12. **Domain-aware evidence:** do not impose a medical evidence hierarchy on computer science or vice versa; match rigor to the field.
13. **No invented resources:** never assume data access, compute, ethics approval, equipment, or collaborators that are not established.
14. **Memory is advisory:** prior feasible/dead-end directions inform but never override current evidence.
