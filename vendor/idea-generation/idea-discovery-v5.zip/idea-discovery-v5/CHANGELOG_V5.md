# V5 Change Log

## Added

- Phase 15 falsifiable hypothesis contract.
- Phase 16 Occam/simplification and counterexample attack.
- Phase 17 blind independent verifier with reduced context.
- Phase 18 minimum viable experiment protocol focused on disconfirmation.
- Phase 19 real-evidence audit and claim/evidence ledger.
- `READY_FOR_MVE` state when design passes but no executed evidence exists.
- `REVISE_EVIDENCE` state for weak/inconclusive or poorly controlled pilot evidence.
- Hard rule: no executed MVE evidence → no final GREENLIGHT.
- `output/mve_evidence/` evidence-ingestion convention and JSON schema.
- `--falsification-only` mode to re-evaluate after pilot evidence is added.
- Falsification-driven revision back-edge to a fresh Phase 10–14 attack loop.
- Final-survivor ELO: READY_FOR_MVE ideas are excluded from validity ranking.
- V5 report/session/dashboard distinction between provisional literature survival and final empirical GREENLIGHT.

## Preserved

- 30–50-paper grounding target and saturation-oriented retrieval.
- Novelty tree + challenge/insight tree.
- Level 1–4 well-established-solution gate.
- Innovator/Pragmatist/Critic multi-round evolution.
- Phase 10–14 destructive literature/reviewer loop.
- Fresh literature search after material revision.
- Quote-or-zero grounding discipline.
- Cross-run ideation memory.
