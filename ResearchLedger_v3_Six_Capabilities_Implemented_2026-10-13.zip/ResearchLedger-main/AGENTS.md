# ResearchLedger instructions for Codex

This repository uses evidence-first scientific research conventions. Start with [CODEX.md](CODEX.md) for the five-stage public contract and [docs/SCIENTIFIC_READINESS.md](docs/SCIENTIFIC_READINESS.md) for claim statuses.

## Paper writing

For S2 drafting or manuscript refinement, explicitly read [skills/paper-orchestra/SKILL.md](skills/paper-orchestra/SKILL.md), then the relevant stage skills in `skills/paper-orchestra-*/SKILL.md`. Consult the **actual original** prompt sources in `vendor/paperorchestra/methods/prompts/` only as guidance, not as executable API agents. The skill is part of this checkout; do **not** require `~/.claude/skills/paper-orchestra`.

Never fabricate study results or citations. Before execution, use `\\PFVAL{id}` and `\\PFFIG{id}` for all empirical outcomes. Keep human-readable manuscript claims consistent with actual evidence receipts. Do not alter locked research protocols, sealed experiment records, or previous result outputs to make a paper look better.

Beihang Referee and Idea Discovery V5 are separate native engines; a skill-read is not proof either ran. Be precise about scripted fixtures versus live model results, and do not describe automated integrity checks as Q1 publication certification.

## Validation

Run targeted offline tests for any modified module. A full-suite pass can only be reported if it actually completed. Leave original vendor source and its licensing intact.
