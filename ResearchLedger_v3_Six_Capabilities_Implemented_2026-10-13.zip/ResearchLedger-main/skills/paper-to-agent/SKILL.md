---
name: paper-to-agent
version: 1.0.0
description: Export reproduced methods as independently testable skills and optional MCP wrappers
---

# Export reproduced methods as independently testable skills and optional MCP wrappers

Require human approval and independent golden-output tests in a network-isolated sandbox. Keep original method, paper, code and fixture hashes. Export tool source, provenance and a clearly labeled optional MCP wrapper; do not imply peer-reviewed correctness.

## Applicable interfaces

Use `researchctl` commands documented in `docs/SIX_CAPABILITIES_V3.md`. Record experiment and evidence receipts. The original V5 10–19 phases, Beihang Referee core/full stages and PaperOrchestra prompts remain intact.
