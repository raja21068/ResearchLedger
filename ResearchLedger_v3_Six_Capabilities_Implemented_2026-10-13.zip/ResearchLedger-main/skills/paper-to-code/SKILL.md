---
name: paper-to-code
version: 1.0.0
description: Reconstruct a method from an authorized scientific paper
---

# Reconstruct a method from an authorized scientific paper

First extract explicit equations, data, procedures, missing implementation details and published metrics. Document assumptions. Generate reproducible code in a scratch directory and use restricted Docker for measurements. Distinguish matching a reported number from independent methodological reproduction.

## Applicable interfaces

Use `researchctl` commands documented in `docs/SIX_CAPABILITIES_V3.md`. Record experiment and evidence receipts. The original V5 10–19 phases, Beihang Referee core/full stages and PaperOrchestra prompts remain intact.
