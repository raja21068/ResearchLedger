---
name: patent-drafting
description: "Transform a research result into a patent draft: restate it as a technical problem, a technical solution with features, the effects it produces, and embodiments a skilled person could carry out. Use when A research result is mature enough that its mechanism could be protected; or when A paper exists and a patent is being derived from it (or directly from the research state); or when You need to decide whether the contribution is a protectable technical solution or only a finding."
---

# Patent Drafting

> Ported from the ConvFusion research-skill library (category: `academic-writing`; origin: stage5.1/output-transformation). Ask/answer using this method whenever it applies to the current research workspace.

## Purpose

Transform a research result into a patent draft: restate it as a technical problem, a technical solution with features, the effects it produces, and embodiments a skilled person could carry out.

## When to Use

Use this skill when:

- A research result is mature enough that its mechanism could be protected.
- A paper exists and a patent is being derived from it (or directly from the research state).
- You need to decide whether the contribution is a protectable technical solution or only a finding.

## Research Method

1. **Start from the research state, not from the paper text.** A patent is organised around a technical problem and its solution; the paper is organised around a scientific argument. Re-derive the technical content rather than renaming sections.
2. **State the technical problem independently.** Describe the deficiency of the prior art in technical terms (what fails, under what conditions), without the paper's framing about gaps or contributions.
3. **Express the solution as technical features.** The solution must be describable as a method or apparatus composed of steps/components. If a claim cannot be written as features, the idea is not yet a patentable solution.
4. **Distinguish patent claims from research claims.** A research claim says something true about the world; a patent claim defines the boundary of an exclusive right. Never copy a research claim into a claim set — restate the feature combination.
5. **State the technical effects as consequences of the solution**, each traceable to a feature that produces it. Effects that come from the evaluation rather than the mechanism are not technical effects.
6. **Describe embodiments in implementable detail.** A skilled person must be able to carry out the solution from the description alone; "as described in the paper" is not an embodiment.
7. **Check the draft is not a renamed paper**: it must contain implementation/embodiment content and claim features that the paper never needed.

## Reasoning Guidance

Focus on:

- Which part of the contribution is a mechanism rather than a measurement.
- The broadest feature set that still solves the technical problem.
- Whether an alternative implementation would fall outside the claim (scope).
- What the prior art already discloses, so the solution is delimited against it.

Avoid:

- Reusing paper headings as patent sections — it produces a draft that cannot be examined.
- Copying research claims into patent claims; they limit no technical feature.
- Claiming effects that were measured rather than produced by the mechanism.
- Omitting embodiments; a draft without them is not enabling.

## Evidence Requirements

Each technical effect stated should be traceable to evidence that the mechanism produces it. The prior-art statements should be traceable to literature evidence. Record which research claims and evidence the draft draws on, so the source research stays answerable.

## Expected Output

Produce:

- technical field and the technical problem of the prior art
- the technical solution stated as features (method/apparatus)
- technical effects, each tied to the feature producing it
- embodiments with implementable detail
- a numbered claim set expressed as feature combinations (not research claims)
- an abstract

## Workspace Conventions

If this method reads or writes structured workspace files (evidence/claims/decisions, plans, papers, outputs, LaTeX, literature search/download), follow the exact schemas in this plugin's `reference/` directory rather than improvising a format — see [research-assets.md](../../reference/research-assets.md), [plans.md](../../reference/plans.md), [papers.md](../../reference/papers.md), [outputs.md](../../reference/outputs.md), [latex.md](../../reference/latex.md), [literature-search.md](../../reference/literature-search.md), and [paper-fulltext-download.md](../../reference/paper-fulltext-download.md), whichever applies. The `research` skill's [SKILL.md](../research/SKILL.md) is the usual entry point that pulls the right context together first; if this skill was invoked on its own, check whether a `project.md` or `research-state.md` already exists in the workspace before assuming there is none.
