---
name: autoresearch-loop
version: 1.0.0
description: Controlled fixed-evaluation autoresearch
---

# Controlled fixed-evaluation autoresearch

Only edit files on the explicit allowlist. Freeze evaluator, protocol, data, primary metric and seeds. Use Docker, track failed candidates and retain only verified numeric improvements. Never claim scientific novelty or independent reproduction from this loop.

## Applicable interfaces

Use `researchctl` commands documented in `docs/SIX_CAPABILITIES_V3.md`. Record experiment and evidence receipts. The original V5 10–19 phases, Beihang Referee core/full stages and PaperOrchestra prompts remain intact.
