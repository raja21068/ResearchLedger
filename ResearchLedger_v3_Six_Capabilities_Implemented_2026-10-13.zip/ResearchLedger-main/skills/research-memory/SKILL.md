---
name: research-memory
version: 1.0.0
description: Evidence-qualified lessons from failed and successful experiments
---

# Evidence-qualified lessons from failed and successful experiments

Store project-scoped indexed lessons linked to hashed artifacts. Label PROPOSED, OBSERVED and REPLICATED explicitly. Disallow invalid promotion, cross-project leaks and ungrounded research conclusions.

## Applicable interfaces

Use `researchctl` commands documented in `docs/SIX_CAPABILITIES_V3.md`. Record experiment and evidence receipts. The original V5 10–19 phases, Beihang Referee core/full stages and PaperOrchestra prompts remain intact.
