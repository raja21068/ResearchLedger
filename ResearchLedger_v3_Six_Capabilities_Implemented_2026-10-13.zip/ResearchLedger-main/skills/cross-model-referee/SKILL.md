---
name: cross-model-referee
version: 1.0.0
description: Independent Claude Code and Codex research concern verification
---

# Independent Claude Code and Codex research concern verification

Keep original Beihang prompts and senior rubric in the native review. Use different model families for author/reviewer/verifier where available. Never silently delete a major concern, invent citation support, or mark closed solely because wording changed.

## Applicable interfaces

Use `researchctl` commands documented in `docs/SIX_CAPABILITIES_V3.md`. Record experiment and evidence receipts. The original V5 10–19 phases, Beihang Referee core/full stages and PaperOrchestra prompts remain intact.
