"""Read-only integration dashboard. Does not bypass Factory or independent evidence gates."""
from __future__ import annotations
import json
from pathlib import Path
from factory.capabilities.common import verify_receipt
from factory.capabilities.skills import catalog

CAPABILITIES=('paper2code','autoresearch','dual-referee','referee-closure','paper2agent')


def inspect(project, skills_root, *, idea_id=None):
    project=Path(project).resolve()
    records={}
    for capability in CAPABILITIES:
        source=project/'control'/'capabilities'/capability
        entries=[]
        if source.is_dir() and not source.is_symlink():
            for path in sorted(source.glob('*/receipt.json')):
                try:
                    data=verify_receipt(path)
                    status=data.get('status','UNKNOWN')
                    entries.append({'id':path.parent.name,'status':status,
                                    'integrity':'PASS','receipt':str(path.relative_to(project))})
                except (ValueError,KeyError,json.JSONDecodeError):
                    entries.append({'id':path.parent.name,'integrity':'FAILED','status':'INVALID'})
        records[capability]=entries
    try:
        skills=catalog(skills_root)
        skill_count=skills['count']
    except ValueError:
        skill_count=0
    v5={'status':'NOT_CHECKED','phases':'10–19 preserved in vendored source'}
    if idea_id:
        from factory.integrations.idea_discovery import phase_audit
        v5=phase_audit(project,idea_id=idea_id)
    return {'schema_version':1,'status':'ENGINEERING_STATUS_NOT_SCIENTIFIC_CERTIFICATION',
            'legacy_stages_unchanged':True,'v5':v5,'skills_available':skill_count,
            'capabilities':records,
            'next':'Run actual Docker experiments, manuscript review, independent assessment and human approval before publishing.'}
