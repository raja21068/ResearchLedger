"""Opt-in research capabilities. Scientific states are never promoted here."""
