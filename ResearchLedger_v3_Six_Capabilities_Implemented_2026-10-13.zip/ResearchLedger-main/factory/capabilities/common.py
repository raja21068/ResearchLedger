"""Deterministic provenance utilities for experimental capabilities."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
from datetime import datetime, timezone
from factory.io import atomic_json


def digest(path):
    path=Path(path)
    if path.is_symlink() or not path.is_file():
        raise ValueError(f"untrusted input path: {path}")
    return hashlib.sha256(path.read_bytes()).hexdigest()


def canonical_hash(obj):
    return hashlib.sha256(json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()


def relative_file(root, name, *, existing=True):
    root=Path(root).resolve()
    p=Path(name)
    if not name or p.is_absolute() or '..' in p.parts or any(part in ('','.','..') for part in p.parts):
        raise ValueError('artifact must use a safe relative path')
    target=root/p
    if any(q.is_symlink() for q in [target,*list(target.parents)[:len(p.parts)]]) or not target.resolve().is_relative_to(root):
        raise ValueError('artifact path must not traverse a symlink')
    if existing and not target.is_file():
        raise ValueError(f'input file missing: {name}')
    return target


def receipt(project, capability, name, payload):
    if not capability.replace('-','').isidentifier() or not name.replace('-','').replace('_','').isalnum():
        raise ValueError('invalid receipt name')
    path=Path(project)/'control'/'capabilities'/capability/name/'receipt.json'
    if path.exists():
        raise ValueError('refusing to overwrite existing receipt')
    record={'schema_version':1,'capability':capability,'name':name,
            'created_at':datetime.now(timezone.utc).isoformat(),**payload}
    record['receipt_sha256']=canonical_hash(record)
    atomic_json(path,record)
    return {'receipt':str(path),'receipt_sha256':record['receipt_sha256'],**payload}


def verify_receipt(path):
    obj=json.loads(Path(path).read_text(encoding='utf-8'))
    expected=obj.pop('receipt_sha256',None)
    if expected!=canonical_hash(obj):raise ValueError('capability receipt integrity mismatch')
    return obj
