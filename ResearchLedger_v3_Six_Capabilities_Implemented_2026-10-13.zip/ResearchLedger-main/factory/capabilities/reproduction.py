"""Paper2Code-inspired reconstruction: method contract -> generated candidate -> Docker comparison."""
from __future__ import annotations
import json
import math
import shutil
from pathlib import Path
from factory.capabilities.common import relative_file,digest,canonical_hash,receipt
from factory.io import atomic_json
from factory.integrations.subscription_bridge import ask_json
from factory import sandbox


def scaffold(project, paper, *, expected_metric=None, tolerance=0.0):
    project=Path(project).resolve()
    source=relative_file(project,paper)
    if not math.isfinite(tolerance) or tolerance<0:raise ValueError('invalid tolerance')
    if expected_metric is not None and (not isinstance(expected_metric,(int,float)) or not math.isfinite(expected_metric)):
        raise ValueError('expected metric must be finite')
    paperhash=digest(source)
    out=project/'reproduction'/('paper-'+paperhash[:16])
    if out.exists():raise ValueError('reproduction plan already exists; do not silently overwrite')
    out.mkdir(parents=True)
    spec={'schema_version':1,'paper':paper,'paper_sha256':paperhash,
          'method_notes':'OPERATOR: describe equations, preprocessing, splits, baselines and ambiguous details here',
          'metric':'score','expected_metric':expected_metric,'tolerance':tolerance,
          'command':['python','reproduce.py'], 'implementation_file':'reproduce.py',
          'status':'AWAITING_OPERATOR_METHOD_REVIEW'}
    atomic_json(out/'plan.json',spec)
    return {'status':spec['status'],'plan':str(out/'plan.json'),'paper_sha256':paperhash}


def _plan(project, plan):
    file=relative_file(project,plan)
    spec=json.loads(file.read_text(encoding='utf-8'))
    if digest(relative_file(project,spec['paper']))!=spec['paper_sha256']:
        raise ValueError('source paper changed after plan')
    if spec.get('implementation_file')!='reproduce.py' or spec.get('command')!=['python','reproduce.py']:
        raise ValueError('reproduction command is not an allowed Docker command')
    if spec.get('metric')!='score':raise ValueError('reproduction metric contract changed')
    if not isinstance(spec.get('tolerance'),(int,float)) or not math.isfinite(spec['tolerance']) or spec['tolerance']<0:
        raise ValueError('invalid tolerance')
    return file,spec


def generate(project, plan, *, provider, model=None):
    project=Path(project).resolve()
    file,spec=_plan(project,plan)
    if provider not in ('claude','codex'):raise ValueError('use logged-in Claude Code or Codex')
    if not spec.get('method_notes') or 'OPERATOR:' in spec['method_notes']:
        raise ValueError('operator must complete method notes before code generation')
    src=relative_file(project,spec['paper'])
    if src.suffix.lower()=='.pdf':
        from pypdf import PdfReader
        paper_text='\n'.join((page.extract_text() or '') for page in PdfReader(str(src)).pages)[:70000]
    elif src.suffix.lower() in ('.md','.txt'):
        paper_text=src.read_text(encoding='utf-8')[:70000]
    else:raise ValueError('supported paper formats: pdf, md, txt')
    if len(paper_text)<50:raise ValueError('paper extraction too short for safe reconstruction')
    response=ask_json(provider,system='Reconstruct methods from a paper into one Python source. Explicitly separate missing details and assumptions. Never fabricate matching results. Program must write JSON {"score": finite_number} to PF_OUT_DIR/metrics.json. Only use Python standard library unless explicitly approved.',user=json.dumps({'paper_excerpt':paper_text,'method_notes':spec['method_notes'],'command':spec['command']},ensure_ascii=False),schema={'type':'object','properties':{'code':{'type':'string'},'assumptions':{'type':'array','items':{'type':'string'}}},'required':['code','assumptions'],'additionalProperties':False},model=model,timeout=900)
    code=response['code']
    if not isinstance(code,str) or len(code)>100000:raise ValueError('invalid generated implementation')
    target=file.parent/'generated'/'reproduce.py'
    if target.exists():raise ValueError('generated implementation already exists')
    target.parent.mkdir(parents=True)
    target.write_text(code,encoding='utf-8')
    atomic_json(target.parent/'assumptions.json',{'assumptions':response['assumptions'],
        'provider':provider,'paper_sha256':spec['paper_sha256'],'code_sha256':digest(target)})
    return {'status':'GENERATED_UNEXECUTED','code':str(target),'code_sha256':digest(target),
            'missing_method_details':response['assumptions']}


def evaluate(project, plan, *, sandbox_factory=None):
    project=Path(project).resolve()
    file,spec=_plan(project,plan)
    code=file.parent/'generated'/'reproduce.py'
    if not code.is_file() or code.is_symlink():raise ValueError('no safe generated implementation; run generate first')
    out=file.parent/'execution'/'out'
    if out.exists():raise ValueError('execution already exists; refuse overwrite')
    engine=(sandbox_factory or (lambda:sandbox.Sandbox()))()
    execution=engine.run(code.parent,['python','reproduce.py'],out,timeout=900)
    result={'status':'EXECUTION_FAILED','paper_sha256':spec['paper_sha256'],
            'implementation_sha256':digest(code),'execution_status':execution.get('status'),
            'reproduction_established':False}
    if execution.get('status')=='PASS' and (out/'metrics.json').is_file():
        data=json.loads((out/'metrics.json').read_text(encoding='utf-8'))
        observed=data.get('score')
        if isinstance(observed,(int,float)) and not isinstance(observed,bool) and math.isfinite(observed):
            reference=spec.get('expected_metric')
            measured=reference is not None and isinstance(reference,(int,float)) and math.isfinite(reference)
            matched=measured and abs(observed-reference)<=spec['tolerance']
            result.update(observed_metric=observed,expected_metric=reference,
                          match=bool(matched),status='MATCHED_SYNTHETIC_OR_LOCAL_BASELINE' if matched else
                          ('MISMATCH' if measured else 'PARTIAL_NO_PUBLISHED_REFERENCE'))
    return receipt(project,'paper2code',file.parent.name,result)
