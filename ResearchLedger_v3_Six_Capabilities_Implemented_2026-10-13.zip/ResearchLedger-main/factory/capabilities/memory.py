"""Project-scoped, evidence-qualified research lessons; sqlite is an index, not a ledger."""
from __future__ import annotations
import hashlib
import json
import sqlite3
from pathlib import Path
from factory.capabilities.common import relative_file,digest

DDL="""CREATE TABLE IF NOT EXISTS lessons (id TEXT PRIMARY KEY, topic TEXT NOT NULL,
lesson TEXT NOT NULL, evidence_path TEXT NOT NULL, evidence_sha256 TEXT NOT NULL,
state TEXT NOT NULL CHECK(state IN ('PROPOSED','OBSERVED','REPLICATED')),
kind TEXT NOT NULL CHECK(kind IN ('FAILURE','SUCCESS','WARNING')));"""


def _db(project):
    root=Path(project).resolve()
    directory=root/'control'/'capabilities'/'memory'
    if directory.is_symlink():raise ValueError('unsafe memory location')
    directory.mkdir(parents=True,exist_ok=True)
    path=directory/'lessons.sqlite3'
    if path.is_symlink():raise ValueError('unsafe database symlink')
    db=sqlite3.connect(path)
    db.execute(DDL)
    return db


def add(project, topic, lesson, evidence, *, state='PROPOSED',kind='FAILURE'):
    if state not in {'PROPOSED','OBSERVED','REPLICATED'}:raise ValueError('invalid evidence state')
    if kind not in {'FAILURE','SUCCESS','WARNING'}:raise ValueError('invalid lesson kind')
    if not isinstance(topic,str) or not isinstance(lesson,str) or not topic.strip() or not lesson.strip() or len(lesson)>20000:
        raise ValueError('invalid lesson')
    file=relative_file(project,evidence)
    sha=digest(file)
    name=hashlib.sha256((topic+'\x00'+lesson+'\x00'+evidence+'\x00'+sha).encode()).hexdigest()[:20]
    with _db(project) as db:
        db.execute('INSERT OR IGNORE INTO lessons VALUES (?,?,?,?,?,?,?)',
                   (name,topic,lesson,evidence,sha,state,kind))
    return {'id':name,'state':state,'evidence_sha256':sha,'scope':'THIS_PROJECT_ONLY'}


def query(project, term='', *, qualified_only=True):
    with _db(project) as db:
        rows=db.execute('SELECT id,topic,lesson,evidence_path,evidence_sha256,state,kind FROM lessons ORDER BY id').fetchall()
    out=[]
    for id_,topic,lesson,path,sha,state,kind in rows:
        if qualified_only and state=='PROPOSED':continue
        if term.lower() not in (topic+' '+lesson).lower():continue
        try: current=digest(relative_file(project,path))
        except ValueError:current=None
        if sha!=current:continue
        out.append(dict(id=id_,topic=topic,lesson=lesson,evidence_path=path,
                        evidence_sha256=sha,state=state,kind=kind))
    return {'status':'INDEX_RESULTS_NOT_NEW_EVIDENCE','scope':'THIS_PROJECT_ONLY','lessons':out}


def promote(project, id_, state, *, approval=False):
    if not approval:raise ValueError('promotion requires explicit human approval')
    if state not in ('OBSERVED','REPLICATED'):raise ValueError('invalid promotion target')
    with _db(project) as db:
        row=db.execute('SELECT state,evidence_path,evidence_sha256 FROM lessons WHERE id=?',(id_,)).fetchone()
        if row is None:raise ValueError('lesson ID missing')
        old,path,sha=row
        if (old,state) not in {('PROPOSED','OBSERVED'),('OBSERVED','REPLICATED')}:
            raise ValueError('invalid promotion transition')
        if digest(relative_file(project,path))!=sha:raise ValueError('original evidence changed')
        db.execute('UPDATE lessons SET state=? WHERE id=?',(state,id_))
    return {'id':id_,'state':state,'note':'Human-approved status, not scientific certification'}
