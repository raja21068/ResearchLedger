"""Controlled candidate experiments: only a trusted controller invokes Docker."""
from __future__ import annotations
import json
import math
import shutil
from pathlib import Path
from factory.capabilities.common import relative_file,digest,receipt,canonical_hash
from factory.io import atomic_json
from factory import sandbox
from factory.integrations.subscription_bridge import ask_json


def _finite(value):
    return isinstance(value,(int,float)) and not isinstance(value,bool) and math.isfinite(value)


def validate_contract(project, contract):
    if not isinstance(contract,dict):raise ValueError('experiment contract must be object')
    edits=contract.get('editable_files')
    if not isinstance(edits,list) or not edits or len(edits)>20 or len(set(edits))!=len(edits):
        raise ValueError('one or more unique editable_files required')
    prohibited={'tests','test','eval','evaluation','_inputs','control','vendor','skills','schemas','.git'}
    for entry in edits:
        if not isinstance(entry,str) or any(c in prohibited for c in Path(entry).parts):
            raise ValueError('editing evaluator/protocol/vendor is prohibited')
        relative_file(project,entry)
        if not entry.endswith('.py'):raise ValueError('only .py editable source is supported')
    command=contract.get('command')
    if not isinstance(command,list) or not command or len(command)>20 or not all(isinstance(c,str) and c and len(c)<500 for c in command):
        raise ValueError('command must be bounded argv strings')
    if command[:1]!=['python'] or any('/' in arg or '\x00' in arg for arg in command[:1]):
        raise ValueError('execution requires python command inside Docker')
    metric=contract.get('metric')
    if not isinstance(metric,str) or not metric.isidentifier():raise ValueError('metric must be an identifier')
    if contract.get('direction') not in ('min','max'):raise ValueError('direction must be min or max')
    if not _finite(contract.get('baseline')):raise ValueError('baseline must be a finite measured metric')
    if not _finite(contract.get('min_delta',0)) or contract.get('min_delta',0)<0:
        raise ValueError('min_delta must be nonnegative')
    if not isinstance(contract.get('max_trials',1),int) or isinstance(contract.get('max_trials',1),bool) or not 1<=contract.get('max_trials',1)<=100:
        raise ValueError('max_trials must be 1..100')
    if 'frozen_files' not in contract or not isinstance(contract['frozen_files'],list) or not contract['frozen_files']:
        raise ValueError('frozen_files must pin the evaluator and experiment inputs')
    pinned=[]
    for file in contract['frozen_files']:
        if file in edits:raise ValueError('editable and frozen files overlap')
        pinned.append({'path':file,'sha256':digest(relative_file(project,file))})
    return {'frozen':pinned,'baseline':contract['baseline'],'metric':metric,
            'direction':contract['direction'],'editable_files':edits,
            'command':command,'min_delta':contract.get('min_delta',0),
            'max_trials':contract.get('max_trials',1)}


def run(project, contract_file, *, provider=None, proposals=None, image=None, sandbox_factory=None):
    project=Path(project).resolve()
    contract_path=relative_file(project,contract_file)
    contract=json.loads(contract_path.read_text(encoding='utf-8'))
    spec=validate_contract(project,contract)
    if proposals is not None and (not isinstance(proposals,list) or not proposals):
        raise ValueError('operator proposals require a nonempty JSON list')
    timeout=contract.get('timeout',900)
    if isinstance(timeout,bool) or not isinstance(timeout,int) or not 1<=timeout<=14400:
        raise ValueError('experiment timeout must be 1..14400 seconds')
    context_file=project/'_inputs'/'context.json'
    if context_file.is_file():
        context=json.loads(context_file.read_text(encoding='utf-8'))
        if context.get('science_mode')=='validation':
            from factory.science.protocol import check
            ok,issues=check(project,context)
            if not ok:
                raise ValueError('validation protocol gate: '+'; '.join(issues))
            if not contract.get('baseline_receipt'):
                raise ValueError('validation experiments need a hashed, inspectable baseline_receipt')
            relative_file(project,contract['baseline_receipt'])
    fingerprint=canonical_hash({'contract':contract,'frozen':spec['frozen']})
    parent=project/'experiments'/('opt-'+fingerprint[:16])
    if parent.exists():raise ValueError('experiment ID already exists: preserve history; create a changed contract')
    parent.mkdir(parents=True)
    trials=[]
    best=spec['baseline']
    runner=(sandbox_factory or (lambda:sandbox.Sandbox(image=image or sandbox.DEFAULT_IMAGE)))()
    max_trials=min(spec['max_trials'],len(proposals) if proposals is not None else spec['max_trials'])
    for n in range(1,max_trials+1):
        name=f'candidate-{n:04d}'
        trial=parent/name
        source=trial/'source'; source.mkdir(parents=True)
        # Scratch clone of project: never allow the agent to mutate locked source.
        for f in spec['frozen']:
            target=relative_file(source,f['path'],existing=False);target.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(relative_file(project,f['path']),target)
        for f in spec['editable_files']:
            target=relative_file(source,f,existing=False);target.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(relative_file(project,f),target)
        if proposals is not None:
            patch=proposals[n-1]
        else:
            if provider not in ('claude','codex'):raise ValueError('live proposals require Claude or Codex login')
            patch=ask_json(provider,system='Research coding assistant. Return a JSON patch for ONE whitelisted Python source file; never modify eval or results. No assertions about run success.',user=json.dumps({'editable_files':spec['editable_files'],'source':{f:relative_file(project,f).read_text(encoding='utf-8')[:30000] for f in spec['editable_files']},'metric':spec['metric'],'goal':spec['direction']}),schema={'type':'object','properties':{'file':{'type':'string'},'content':{'type':'string'}},'required':['file','content'],'additionalProperties':False})
        if not isinstance(patch,dict) or patch.get('file') not in spec['editable_files'] or not isinstance(patch.get('content'),str) or len(patch['content'])>150000:
            raise ValueError('model proposal violated edit contract')
        relative_file(source,patch['file']).write_text(patch['content'],encoding='utf-8')
        if any(digest(relative_file(project,f['path']))!=f['sha256'] for f in spec['frozen']):
            raise ValueError('frozen evaluator changed during run')
        out=trial/'out'
        execution=runner.run(source,spec['command'],out,timeout=timeout)
        score=None
        status='FAILED'
        try:
            metric_file=out/'metrics.json'
            if execution['status']=='PASS' and metric_file.is_file() and not metric_file.is_symlink():
                metrics=json.loads(metric_file.read_text(encoding='utf-8'))
                value=metrics.get(spec['metric'])
                if _finite(value):
                    score=value
                    improved=(value>best+spec['min_delta'] if spec['direction']=='max' else value<best-spec['min_delta'])
                    status='KEPT' if improved else 'REVERTED'
                    if improved:best=value
        except (OSError,ValueError,TypeError,json.JSONDecodeError):pass
        event={'candidate':name,'status':status,'metric':score,'best':best,
               'execution_status':execution.get('status'),'patch_sha256':digest(relative_file(source,patch['file'])),
               'out_sha256':digest(out/'metrics.json') if (out/'metrics.json').is_file() else None}
        atomic_json(trial/'event.json',event)
        trials.append(event)
    summary={'status':'SANDBOX_TRIALS_COMPLETE_NOT_SCIENTIFICALLY_VERIFIED','experiment_id':parent.name,
             'contract_sha256':digest(contract_path),'baseline':spec['baseline'],
             'best':best,'trials':trials,'proposal_source':'operator-fixtures' if proposals is not None else 'model-cli',
             'model_cli_executed':proposals is None,'provider':None if proposals is not None else provider,
             'baseline_independently_verified':False,'scientific_validation':False}
    atomic_json(parent/'summary.json',summary)
    return receipt(project,'autoresearch',parent.name,summary)
