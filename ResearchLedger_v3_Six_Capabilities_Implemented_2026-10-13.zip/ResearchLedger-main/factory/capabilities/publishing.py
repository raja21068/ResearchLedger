"""Paper2Agent-inspired SKILL and optional MCP packaging; no publication without golden test."""
from __future__ import annotations
import hashlib
import json
import shutil
from pathlib import Path
from factory.capabilities.common import relative_file,digest,receipt
from factory.io import atomic_json
from factory import sandbox

RUNNER="""import importlib.util, json, os
from pathlib import Path
spec=importlib.util.spec_from_file_location("exported_tool", "/workspace/tool.py")
mod=importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
fixtures=json.loads(Path("/workspace/fixtures.json").read_text())
outputs=[mod.run(item["input"]) for item in fixtures]
Path(os.environ["PF_OUT_DIR"]).joinpath("golden_results.json").write_text(json.dumps(outputs,allow_nan=False))
"""
MCP="""'''Optional MCP wrapper. Requires installing the official mcp Python package.'''
from mcp.server.fastmcp import FastMCP
from tool import run
server=FastMCP("ResearchLedger-export")
@server.tool()
def research_tool(payload: dict) -> dict:
    '''Invoke the published method, given an authorized JSON payload.'''
    return run(payload)
if __name__=='__main__':
    server.run()
"""


def build(project, code, golden, *, name, approve=False, sandbox_factory=None):
    project=Path(project).resolve()
    if not approve:raise ValueError('explicit operator approval required to package research code')
    if not name or not name.replace('-','').replace('_','').isalnum():
        raise ValueError('unsafe published agent name')
    code_path=relative_file(project,code)
    golden_path=relative_file(project,golden)
    if code_path.suffix!='.py':raise ValueError('expected a Python tool implementation')
    fixtures=json.loads(golden_path.read_text(encoding='utf-8'))
    if not isinstance(fixtures,list) or not fixtures or len(fixtures)>100 or not all(isinstance(x,dict) and set(x)=={'input','expected'} for x in fixtures):
        raise ValueError('golden fixtures need input/expected pairs')
    target=project/'published_agents'/name
    if target.exists():raise ValueError('publishing cannot overwrite existing output')
    target.mkdir(parents=True)
    src=target/'source';src.mkdir()
    shutil.copyfile(code_path,src/'tool.py')
    (src/'fixtures.json').write_text(json.dumps(fixtures,allow_nan=False),encoding='utf-8')
    (src/'runner.py').write_text(RUNNER,encoding='utf-8')
    out=target/'verification'
    engine=(sandbox_factory or (lambda:sandbox.Sandbox()))()
    executed=engine.run(src,['python','runner.py'],out,timeout=600)
    passed=False
    if executed.get('status')=='PASS' and (out/'golden_results.json').is_file():
        outputs=json.loads((out/'golden_results.json').read_text(encoding='utf-8'))
        passed=[x['expected'] for x in fixtures]==outputs
    provenance={'name':name,'source_path':code,'source_sha256':digest(code_path),
                'golden_path':golden,'golden_sha256':digest(golden_path),
                'test_count':len(fixtures),'golden_passed':passed,
                'sandbox_status':executed.get('status'),
                'scientific_claims_verified':False}
    atomic_json(target/'provenance.json',provenance)
    if passed:
        folder=target/'skill';folder.mkdir()
        shutil.copyfile(src/'tool.py',folder/'tool.py')
        (folder/'SKILL.md').write_text('---\nname: '+name+'\ndescription: Evidence-linked tool export; independently inspect the provenance before reuse.\n---\n\nRun using the supplied tool.py; never treat code output as independently validated scientific evidence.\n',encoding='utf-8')
        (folder/'mcp_server.py').write_text(MCP,encoding='utf-8')
        (folder/'provenance.json').write_text(json.dumps(provenance,indent=2),encoding='utf-8')
    return receipt(project,'paper2agent',name,{'status':'GOLDEN_TEST_PASSED_NOT_SCIENTIFICALLY_VERIFIED' if passed else 'BLOCKED_GOLDEN_TEST_FAILED',
         'publication_path':str(target/'skill') if passed else None,**provenance})
