"""Local versioned skill discovery. No installation or execution during scanning."""
from __future__ import annotations
import hashlib
import json
import re
from pathlib import Path
from factory.capabilities.common import relative_file, canonical_hash

NAME=re.compile(r'^[a-z][a-z0-9-]{1,70}$')


def catalog(root):
    root=Path(root).resolve()
    if not root.is_dir():raise ValueError('skills directory missing')
    result=[]
    for folder in sorted(root.iterdir()):
        if folder.is_symlink() or not folder.is_dir():continue
        name=folder.name
        if not NAME.fullmatch(name):continue
        entry=folder/'SKILL.md'
        if not entry.is_file() or entry.is_symlink():continue
        text=entry.read_text(encoding='utf-8')
        if len(text)>200_000:raise ValueError(f'skill too large: {name}')
        items=[]
        for file in sorted(folder.rglob('*')):
            if file.is_symlink():raise ValueError(f'symlink inside skill {name}')
            if file.is_file():
                rel=file.relative_to(folder).as_posix()
                items.append((rel,hashlib.sha256(file.read_bytes()).hexdigest()))
        meta={}
        if text.startswith('---\n'):
            header=text.split('---',2)[1]
            for line in header.splitlines():
                if ':' in line:
                    key,val=line.split(':',1)
                    if key.strip() in ('name','description','version'):
                        meta[key.strip()]=val.strip().strip('"\'')
        result.append({'name':name,'version':meta.get('version','0.0.0+local'),
                       'description':meta.get('description','').strip(),
                       'files':len(items),'sha256':canonical_hash(items),
                       'path':str(entry)})
    return {'status':'CATALOG_ONLY','skills':result,'count':len(result),
            'execution':'NOT_EXECUTED','note':'A skill is instructions, not scientific validation.'}


def resolve(root, name, *, expected_sha256=None):
    if not NAME.fullmatch(name):raise ValueError('invalid skill name')
    result=catalog(root)
    match=next((s for s in result['skills'] if s['name']==name),None)
    if match is None:raise ValueError(f'unknown skill: {name}')
    if expected_sha256 and expected_sha256!=match['sha256']:
        raise ValueError('skill version/digest changed')
    return match
