## 2026-10-12 — opt-in native specialist integration (engineering build, unreleased)

- Added a first-class `researchctl idea-discovery run` bridge to execute the actual bundled Idea Discovery V5 code with project-local source papers, separate API configuration, dry-run and bounded runtime.
- Added `researchctl idea-discovery adopt` to import one **operator-acknowledged** `READY_FOR_MVE`/`GREENLIGHT` V5 survivor into Factory S1, with SHA-bound source reports and an explicit numeric falsifier; no invented extra candidate ideas or pseudo-review scores.
- Added native `researchctl referee inspect`, `review`, `compare`, and `iterate` commands. Native Referee Lean v2 executes its actual seven-stage pipeline in the project workspace rather than a lightweight instruction-only imitation.
- Added optional `review_agent: referee-native` for Factory S3/S5, with guarded editing and re-review; backed by Referee's admitted concerns and invariant gates instead of inferred numeric referee scorecards.
- Added deliberately scripted 3-round sample (`1 → 1 → 0` admitted major concerns), V5 idea schema check, real manuscript package inspection, 10 new cross-engine tests, and CI native-vendor smoke job.
- **Not demonstrated:** real model-backed V5 idea generation or real provider-based Referee review, empirical improvement in science, independent reproductions, or journal readiness; offline run uses scripted fixtures and edited example manuscripts.

## Unreleased — Engineering hardening (12 October 2026)

- Added validated, non-executing per-project extraction of bundled Idea Discovery v5 with `researchctl idea-discovery inspect/prepare`.
- Reject invalid, duplicate and non-finite generated idea/reviewer data; atomically write idea artifacts.
- Make BibTeX and intermediate LaTeX failures fatal instead of silently continuing.
- Bound runner log capture and terminate descendant POSIX processes on timeout.
- Fix dual-suite Pytest module collisions, clearly skip omitted historical trajectory fixtures, and consolidate CI on supported Python versions.
- Remove machine-specific Claude permissions and generated build/cache files from the release ZIP; update documentation and research-agent comparison.
- Detailed limitations and unresolved items: [engineering report](docs/ENGINEERING_AUDIT_2026-10-12.md).

## 2.0.1 — Post-release forensic code and packaging audit (2026-10-08)

- Restore missing ResearchLedger hooks, quickstart examples and validation-study fixtures so the complete shipped test suite can execute.
- Reject unsafe Docker mount symlinks (including parent-directory and nested paths).
- Bound isolated-repeat tolerances; reject forged/unsafe comparison settings on subsequent checks.
- Preserve existing repository SHA-256 hashes while switching to streaming, symlink-safe hashing.
- Put new workspaces in a user-writable location by default, with an environment override and legacy-checkout compatibility.
- Validate malformed DOI registry entries explicitly, and clarify that a recorded run is not proof of a successful reproduction.
- Add post-audit regression tests and a detailed audit report, including limitations.

# Release history

## 2.0.0 — Evidence-first integration (2026-10-08)

- Added a mode selector: `exploration` or opt-in `validation`. Older exploration projects retain the v1 execution path.
- Added prospective operator-authored protocol scaffolds and hash-bound protocol/idea/dataset locks, enforced before the manuscript skeleton and experiments in validation mode.
- Added explicit Crossref DOI resolution with bounded responses and tamper-checked metadata receipts; nearest-prior-art matrix with operator acknowledgement.
- Added quantitative claim contracts requiring named metric slots, a population/scope statement, real metric values from the linked S4 ResearchLedger run, and source/receipt hash consistency.
- Added validation-data experiment prompts prohibiting silent synthetic fallback, with required registered seed reporting, dataset-use attestation and measured sample count.
- Added descriptive multi-seed arithmetic checks that reject inconsistent metric aggregates without claiming inferential significance.
- Added isolated repeat of the same generated experiment in restricted Docker, with numeric/series/per-seed comparison and receipt checks. No host execution and no automatic promotion to scientifically verified evidence.
- Added science integrity gates before S5 in validation mode, advisory science audit for all projects, new CLI commands, and stage-scoped checkpoint signatures to permit prospective research records between stages.
- Added regression tests for locks, tampering, metadata spoofing, declared-claim coverage, seed arithmetic, Docker repeat and checkpoint boundaries.

### Not yet implemented

A true experiment-before-draft stage redesign, independent replication by a second implementation, verified literature *findings*, fully automatic review of prose, unbiased statistical inference, leakage classifiers, and a visual monitoring dashboard. See `docs/EVIDENCE_FIRST_V2.md`.

## 1.0.0

First Paper Factory v0.2 + ResearchLedger v2.2 integration with Docker experiment import and tamper-checked evidence ledger.
