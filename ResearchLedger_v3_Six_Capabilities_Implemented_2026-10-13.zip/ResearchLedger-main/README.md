<div align="center">

# ResearchLedger × Paper Factory

### An evidence-first research workflow — from falsifiable ideas to traceable results

**Generate ideas · Draft manuscripts · Simulate peer review · Execute experiments · Audit claims**

[![Python 3.10+](https://img.shields.io/badge/Python-3.10%2B-3776AB?logo=python&logoColor=white)](https://www.python.org/) [![Release](https://img.shields.io/badge/version-2.0.1-334155)](pyproject.toml) [![Research workflow](https://img.shields.io/badge/workflow-evidence--first-0F766E)](docs/EVIDENCE_FIRST_V2.md) [![arXiv related](https://img.shields.io/badge/related%20paper-arXiv%3A2607.02520-B31B1B?logo=arxiv&logoColor=white)](https://arxiv.org/abs/2607.02520)

[**Quick start**](#-quick-start) · [**How it works**](#-how-it-works) · [**Scientific safeguards**](#-scientific-safeguards) · [**Agent landscape**](docs/RESEARCH_AGENT_COMPARISON.md) · [**Documentation**](#-documentation)

</div>

---

## Why ResearchLedger?

A research assistant can produce a convincing paper even when its experiments do not run, its citations are unverified, or its findings cannot be traced back to data. **ResearchLedger combines an agentic paper-production pipeline with an explicit scientific evidence ledger**, making the distinction between *generated text*, *executed measurements*, and *independently established findings* visible.

**Paper Factory** orchestrates idea selection, LaTeX drafting, AI review, isolated code execution, and revision. **ResearchLedger** tracks hypotheses, runs, provenance, evidence status, and claim relationships. The opt-in **validation mode** adds prospective protocol and result-integrity checks before finalization.

> [!IMPORTANT]
> This is research software, **not** a scientific correctness, novelty, independent-replication, journal-acceptance, or Q1-publication certifier. An automated integrity pass confirms defined machine-checkable conditions only. Domain expertise, research ethics, statistical scrutiny, and independent review remain essential.

## ✨ Highlights

| Capability | What it does for researchers |
| --- | --- |
| **Falsifiable idea selection** | Generates candidate research ideas, scores them through two critical personas, and enforces measurable falsification criteria. |
| **Bundled PaperOrchestra writing skills** | Six first-party skills orchestrate outlines, literature, sections, figures and refinement using the vendored prompts and an authenticated Claude Code **or Codex** CLI, without a separate `~/.claude/skills` install. [Guide](docs/PAPERORCHESTRA_SKILLS.md) |
| **Evidence-aware writing** | Drafts with **empty result placeholders** first; inserts numerical findings only from explicitly bound executed outputs. |
| **Scientific review and revision** | Produces structured manuscript feedback, checks concerns, and supports bounded revision rounds. |
| **Isolated experiments** | Runs generated experiments inside a network-restricted Docker environment; retains code, result, and input provenance. |
| **ResearchLedger provenance** | Connects claims **C###**, evidence **E###**, and runs **R####** using digests and validation checks. |
| **Opt-in validation gates** | Locks research protocol and dataset, audits prior-art metadata, checks metric mappings and registered seeds, and performs isolated repeats. |
| **Real vendor-agent execution** | Runs actual [Idea Discovery v5](docs/IDEA_DISCOVERY_V5.md) and [Referee Lean v2](docs/NATIVE_VENDOR_ENGINES.md) engines by explicit CLI commands; S3/S5 can opt into native Referee. |

## 🧪 Six optional research capabilities — engineering preview (October 2026)

The following **newly implemented, opt-in commands** expand the Factory without modifying Idea Discovery V5 phases 10–19, Beihang Referee's original `core/full` prompts, the 49 vendored PaperOrchestra files, or legacy S1–S5:

| Capability | Command | Current implementation boundary |
| --- | --- | --- |
| **Autoresearch trials** | `researchctl autoresearch` | Candidate patches → frozen-file check → restricted Docker → measured keep/revert; not an independent scientific replication |
| **Paper2Code-inspired reconstruction** | `researchctl reproduce-paper` | Source-paper fingerprint → method plan → Claude/Codex code generation → Docker measurement; not the upstream Paper2Code engine |
| **Cross-model Beihang concern audit** | `researchctl referee normalize-beihang / dual-review / closure-check` | Native admitted concerns → opposite CLI model → sticky open issue records; model agreement is not scientific proof |
| **Research failure memory** | `researchctl memory` | Project-local SQLite index of evidence-linked lessons; explicit approval for promotion |
| **Scientific skill catalog** | `researchctl skills` | Discovers and hashes versioned `SKILL.md` packages without executing them |
| **Paper2Agent-inspired publication** | `researchctl paper2agent` | Operator-approved golden-tested skill export and optional MCP wrapper; no deployment or scientific certification |

Inspect the read-only cross-capability status using `researchctl workflow status PROJECT`. **An automatic end-to-end six-component DAG, live Claude/Codex runs, and independent benchmark validation are not yet demonstrated.** The complete [usage guide](docs/SIX_CAPABILITIES_V3.md) describes required inputs, permissions, example commands and failure states.

## 🔄 How it works

```mermaid
flowchart LR
    A[Research question] --> B[S1: Idea selection]
    B --> C[S2: LaTeX draft + empty result slots]
    C --> D[S3: Referee assessment]
    D --> E[S4: Sandboxed code + measured results]
    E --> F[S5: Evidence-bound revision]
    F --> G[Audit + researcher review]
    B -. hypothesis .-> L[(ResearchLedger)]
    E -. run + evidence .-> L
    F -. claim linkage .-> L
```

**Exploration mode** is the default and yields exploratory results. **Validation mode** is opt-in and requires an operator-reviewed, prospectively locked protocol and declared result contracts. It does not retroactively turn a pilot into a confirmatory study.

## 🚀 Quick start

### Prerequisites

- **Python 3.10+**, `pip`, an authenticated **Claude Code or Codex CLI**, and a local LaTeX toolchain (`pdflatex`, `bibtex`).
- **Docker Desktop or Docker Engine** for experiment execution; a pinned runtime image and offline dependency setup are expected.
- Vendor/template dependencies described in [START_HERE.md](START_HERE.md). The editable installation uses files from this source checkout; a standalone non-editable wheel is not supported yet.

```bash
git clone https://github.com/raja21068/ResearchLedger.git
cd ResearchLedger
python -m pip install -e .
researchctl doctor
researchctl init "brain tumor robustness"
```

Edit `_inputs/topic.md` inside the **workspace path printed by** `researchctl init`, then run:

```bash
researchctl run --project brain-tumor-robustness
researchctl status brain-tumor-robustness
researchctl ledger brain-tumor-robustness
researchctl audit brain-tumor-robustness
```

New projects normally live under `~/.local/share/paperfactory/workspaces/`; the path can be overridden with `PAPERFACTORY_WORKSPACES`, and existing checkout-local workspaces are supported for compatibility. The CLI uses your existing Claude Code login; it does not require a separate Factory API key.

### Opt-in validation workflow

Set `"science_mode": "validation"` in the new project's `_inputs/context.json` **before the research run**. Supply a real, appropriately licensed dataset and the required protocol information. Follow the detailed operator sequence in [Evidence-first v2](docs/EVIDENCE_FIRST_V2.md).

```bash
researchctl run --project brain-tumor-robustness --to S1
researchctl protocol lock brain-tumor-robustness
researchctl literature verify brain-tumor-robustness --doi 10.XXXX/example
researchctl literature audit brain-tumor-robustness
researchctl run --project brain-tumor-robustness --from S2 --to S4
researchctl claims scaffold brain-tumor-robustness
researchctl claims bind brain-tumor-robustness
researchctl reproduce-isolated brain-tumor-robustness
researchctl science-audit brain-tumor-robustness
```

The DOI above is a **placeholder**, not a real citation. Populate the protocol, prior-art matrix, and claim bindings before their corresponding audit steps. The run is not automatically publication-ready after an audit pass.

## 🧠 Specialist agents and integration boundaries

| Layer | Repository component | Scope | Integration status |
| --- | --- | --- | --- |
| **Idea generation** | [`factory/steps/idea.py`](factory/steps/idea.py) | Candidate ideas, critical personas, numerical falsifiability gate | **Default Factory S1** |
| **Bundled idea research** | [`vendor/idea-generation/idea-discovery-v5.zip`](vendor/idea-generation/idea-discovery-v5.zip) | Additional idea-discovery distribution | **Opt-in native run, with explicit V5 survivor adoption into S1 (not S1 default)** |
| **Factory peer review** | [`factory/steps/review.py`](factory/steps/review.py) | Structured feedback, PDF anchors, guarded revision | **Default Factory S3/S5** |
| **Specialist review engine** | [`Referee Lean v2`](vendor/20-%20Paper%20Review%20Agent/Referee-Lean-v2/README.md) | Reviewer roles, evidence-verification procedures, red-team review, concern closure | **Native engine exposed through `researchctl referee`; opt-in real S3/S5 review backend** |
| **Evidence and integrity** | [`researchledger/`](researchledger/) and [`factory/science/`](factory/science/) | Claim/evidence/run graph, protocol and metric checks | **Integrated; validation mode opt-in** |

> **Implementation clarity:** A vendored agent is a real packaged component, but *presence in `vendor/` is not proof that the complete specialist workflow runs on each `researchctl run`*. This README deliberately distinguishes the available distribution from the standard orchestration path. [Inspect and prepare Idea Discovery v5](docs/IDEA_DISCOVERY_V5.md) using `researchctl idea-discovery inspect` and `researchctl idea-discovery prepare PROJECT`.

## 🧩 Native specialist engines · now executable

The project bundles two substantial specialist packages. You can **run their actual implementations**, rather than merely loading their prompts. Both remain opt-in, and API credentials are configured locally.

| Native engine | What it does | Command |
| --- | --- | --- |
| **Idea Discovery V5** | Literature/idea pipeline, hostile novelty attacks, falsification and MVE evidence states | `researchctl idea-discovery run PROJECT --paper paper.pdf --topic "..."` |
| **V5 → S1 adoption** | Operator-approved V5 survivor enters Factory S1 with a source checksum and concrete falsifier | `researchctl idea-discovery adopt PROJECT ... --acknowledge-manual` |
| **Referee Lean v2** | Native specialist reviewer and evidence/invariant gates | `researchctl referee review PROJECT paper.pdf --model MODEL` |
| **Iterated Referee** | Re-review multiple manuscript versions with native revision diffs | `researchctl referee iterate PROJECT v1.md v2.md v3.md --model MODEL` |
| **Factory S3/S5 native mode** | Native Referee critique + guarded Factory LaTeX revision + repeated critique | `_inputs/context.json`: `"review_agent": "referee-native"` |

**Try the deterministic worked example:**

```bash
python examples/native_vendor_demo/generate_fixtures.py
python examples/native_vendor_demo/run_offline_demo.py --workspace ./tmp/vendor-smoke
```

This invokes the real Referee pipeline on three illustrative manuscript versions and exercises V5's real schema validator. It intentionally uses scripted reviewer responses (no AI model calls). The example displays concern counts **1 → 1 → 0**, which is a regression-test result, **not** proof of AI reviewing accuracy. The genuine V5 generative pipeline and live Referee reviewing require configured model APIs.

[**Native integration guide, commands, debugging and caveats →**](docs/NATIVE_VENDOR_ENGINES.md)

## 🔬 Scientific safeguards

| Safeguard | What is checked | What it **does not** establish |
| --- | --- | --- |
| Protocol lock | Prospective local protocol, selected idea, data and registered metadata integrity | External preregistration or methodological adequacy |
| Literature check | DOI bibliographic metadata and operator-completed prior-art register | Claim support, exhaustive literature search, or novelty |
| Experiment receipt | Docker result, expected metrics, artifact and dataset/code digests | Correct design, sound statistics, absence of leakage |
| Claim mapping | Required result slots mapped to measured runs | Every free-text scientific assertion |
| Isolated repeat | Same implementation rerun under a restricted container and declared tolerances | Independent reimplementation or external replication |
| Scientific audit | Automated integrity constraints | Scientific validity or editorial acceptance |

The system deliberately differentiates **hypothesis → checked evidence → provisional claim** from externally verified evidence. See [Scientific Readiness](docs/SCIENTIFIC_READINESS.md).

## 📊 Research-agent landscape

How does ResearchLedger differ from idea-generation agents, reviewer simulations, autonomous scientists, physical laboratories, and paper-to-code tools?

Explore the **[categorized research-agent comparison and large 10-dimension signature matrix](docs/RESEARCH_AGENT_COMPARISON.md)** covering systems such as AI Scientist-v2, Google Co-Scientist, Robin, A-Lab, Agora, EviGraph, IDEAgent, ReviewGrounder, DeepReviewer, Paper2Agent, and PaperOrchestra.

The comparison is **qualitative and architecture-based**, not a claim that ResearchLedger outperforms those systems. It separates **cognitive, operational, epistemic, and institutional autonomy** from memory, physical experimentation, evidence lineage, repeatability, prompts, and human oversight.

## 📖 Related research

**[AutoResearch: An Execution-Grounded Multi-Agent Framework for Reliable Research Workflow Automation](https://arxiv.org/abs/2607.02520)**  
Rajesh Kumar, Waqar Ali, Junaid Ahmed, Abdullah Aman Khan, Shaoning Zeng · [arXiv:2607.02520](https://doi.org/10.48550/arXiv.2607.02520) · Submitted May 4, 2026.

This paper presents **AutoResearch**, a *related but separate* research framework; its experimental results should **not** be interpreted as validation of this ResearchLedger repository. See the [AutoResearch source repository](https://github.com/raja21068/AutoResearch).

### Cite the related preprint

```bibtex
@misc{kumar2026autoresearch,
  title={AutoResearch: An Execution-Grounded Multi-Agent Framework for Reliable Research Workflow Automation},
  author={Kumar, Rajesh and Ali, Waqar and Ahmed, Junaid and Khan, Abdullah Aman and Zeng, Shaoning},
  year={2026},
  eprint={2607.02520},
  archivePrefix={arXiv},
  primaryClass={cs.CY},
  doi={10.48550/arXiv.2607.02520}
}
```

## 🧪 Tests and diagnostics

```bash
python -m unittest discover -s tests -p 'test_*.py'
python -m pytest -q tests_researchledger
researchctl test
```

Passing tests and automated research gates does **not** substitute for domain-specific end-to-end scientific validation. Full model, Docker, LaTeX, and dataset workflows require local execution.

## 📚 Documentation

| Guide | Start here when… |
| --- | --- |
| [Getting started](START_HERE.md) | You want the shortest reliable installation path |
| [Evidence-first operator guide](docs/EVIDENCE_FIRST_V2.md) | You need a locked-protocol validation workflow |
| [Architecture](docs/ARCHITECTURE.md) | You want to understand each Factory stage |
| [Idea Discovery v5](docs/IDEA_DISCOVERY_V5.md) | You want to run or explicitly adopt a V5 research idea |
| [Native vendor integrations](docs/NATIVE_VENDOR_ENGINES.md) | You want to execute and test real V5 and Referee engines, including reviewer revision loops |
| [Integration](docs/INTEGRATION.md) | You want to understand the Factory–Ledger boundary |
| [Scientific readiness](docs/SCIENTIFIC_READINESS.md) | You need definitions of checked, provisional, and verified |
| [Research-agent comparison](docs/RESEARCH_AGENT_COMPARISON.md) | You want the categorized comparison and signature matrix |
| [Engineering audit](docs/DEEP_CODE_AUDIT_2026-10-08.md) | You want the original release audit notes |
| [October 2026 hardening report](docs/ENGINEERING_AUDIT_2026-10-12.md) | You want fixes, regression coverage, and remaining engineering risks |

## 🤝 Contributing and provenance

ResearchLedger is a research prototype designed for transparent scientific workflows. Contributions that strengthen error detection, reproducibility, evidence validation, documentation, or independent benchmarking are especially useful. Please include reproducible test cases and specify what each test does and does not establish.

The integration retains the upstream **ResearchLedger Apache-2.0** license text under [`licenses/RESEARCHLEDGER_APACHE-2.0.txt`](licenses/RESEARCHLEDGER_APACHE-2.0.txt). Vendored components may have separate licenses and attribution requirements; inspect them before redistribution.

---

<div align="center">

**Generated research is a starting point. Evidence is the standard.**

[Get started](START_HERE.md) · [Examine the science gates](docs/EVIDENCE_FIRST_V2.md) · [Compare research agents](docs/RESEARCH_AGENT_COMPARISON.md)

</div>

## 🎻 Bundled PaperOrchestra skills

S2 manuscript drafting now uses [`skills/paper-orchestra/SKILL.md`](skills/paper-orchestra/SKILL.md) and its five stage-specific skills. They reference the **original vendored PaperOrchestra prompt recipes** in [`vendor/paperorchestra/`](vendor/paperorchestra/). No separate `~/.claude/skills/paper-orchestra` installation is needed for the source checkout. Configure `"writer_provider": "claude"` or `"codex"` in `_inputs/context.json`. This **skill-driven Claude/Codex workflow is different from executing the upstream API-backed PaperOrchestra Python pipeline**.

[**Setup, scope, and improvement roadmap →**](docs/PAPERORCHESTRA_SKILLS.md)
