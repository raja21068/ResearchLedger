"""Offline first-party contract and adversarial checks for the six optional capabilities."""
import json
import tempfile
from pathlib import Path
from unittest.mock import patch
import pytest
from factory.capabilities import common, skills, memory, experiments, reproduction, referee, publishing
from factory.cli.main import main

@pytest.fixture
def project(tmp_path):
    root=tmp_path/'project';root.mkdir()
    (root/'model.py').write_text('x = 1\n')
    (root/'evaluation.py').write_text('from pathlib import Path\n')
    (root/'paper.md').write_text('This paper documents a toy reproducible method using explicit algebra. '*4)
    return root

class DockerFixture:
    def __init__(self, metrics=None, status='PASS'):
        self.metrics=metrics or {'score':0.75}
        self.status=status
        self.calls=0
    def run(self, repo, command, out, **kwargs):
        self.calls+=1
        assert Path(repo).is_dir()
        assert command[0]=='python'
        out=Path(out);out.mkdir(parents=True,exist_ok=True)
        if self.status=='PASS':
            (out/('golden_results.json' if 'runner.py' in command else 'metrics.json')).write_text(json.dumps(self.metrics))
        return {'status':self.status,'image':'fake-docker-fixture','network':'none'}

def test_catalog_and_symlink(tmp_path,project):
    result=skills.catalog(Path(__file__).resolve().parents[1]/'skills')
    assert all(x in {i['name'] for i in result['skills']} for x in (
        'autoresearch-loop','paper-to-code','cross-model-referee','research-memory',
        'scientific-skill-router','paper-to-agent','paper-orchestra'))
    selected=skills.resolve(Path(__file__).resolve().parents[1]/'skills','paper-to-code')
    assert selected['sha256']==skills.resolve(Path(__file__).resolve().parents[1]/'skills','paper-to-code',expected_sha256=selected['sha256'])['sha256']
    with pytest.raises(ValueError):skills.resolve(Path(__file__).resolve().parents[1]/'skills','../paper-to-code')
    (project/'evil.txt').symlink_to(project/'model.py')
    with pytest.raises(ValueError):common.relative_file(project,'evil.txt')

def test_receipts_fail_on_tampering(project):
    result=common.receipt(project,'sample','first',{'status':'TEST'})
    p=Path(result['receipt'])
    assert common.verify_receipt(p)['status']=='TEST'
    data=json.loads(p.read_text());data['status']='PASS';p.write_text(json.dumps(data))
    with pytest.raises(ValueError):common.verify_receipt(p)

def test_memory_scoped_evidence_and_explicit_promotion(project,tmp_path):
    first=memory.add(project,'unstable seed','variance exceeded policy','evaluation.py')
    assert memory.query(project,'unstable')['lessons']==[]
    with pytest.raises(ValueError):memory.promote(project,first['id'],'OBSERVED')
    assert memory.promote(project,first['id'],'OBSERVED',approval=True)['state']=='OBSERVED'
    assert len(memory.query(project,'unstable')['lessons'])==1
    other=tmp_path/'other';other.mkdir()
    assert memory.query(other,'unstable')['lessons']==[]
    (project/'evaluation.py').write_text('changed')
    assert memory.query(project,'unstable')['lessons']==[]
    with pytest.raises(ValueError):memory.promote(project,first['id'],'REPLICATED',approval=True)

def test_autoresearch_keeps_reverts_and_blocks_frozen_edits(project):
    contract={'editable_files':['model.py'],'frozen_files':['evaluation.py'],
              'metric':'score','direction':'max','baseline':0.5,'min_delta':0.02,
              'command':['python','evaluation.py'],'max_trials':2}
    (project/'exp.json').write_text(json.dumps(contract))
    class MultiDocker:
        def __init__(self):self.n=0
        def run(self,repo,command,out,**kw):
            self.n+=1
            out=Path(out);out.mkdir(parents=True,exist_ok=True)
            (out/'metrics.json').write_text(json.dumps({'score':0.6 if self.n==1 else 0.4}))
            return {'status':'PASS'}
    result=experiments.run(project,'exp.json',proposals=[{'file':'model.py','content':'x=2'},{'file':'model.py','content':'x=3'}],sandbox_factory=MultiDocker)
    assert [x['status'] for x in result['trials']]==['KEPT','REVERTED']
    assert (project/'model.py').read_text()=='x = 1\n'
    assert result['best']==0.6
    assert common.verify_receipt(result['receipt'])['best']==0.6
    with pytest.raises(ValueError):experiments.run(project,'exp.json',proposals=[],sandbox_factory=MultiDocker)
    contract['editable_files']=['evaluation.py']
    (project/'exp2.json').write_text(json.dumps(contract))
    with pytest.raises(ValueError):experiments.validate_contract(project,contract)

def test_reproduce_scaffold_generate_evaluate_and_paper_mutation(project):
    p=reproduction.scaffold(project,'paper.md',expected_metric=0.75,tolerance=0.001)
    plan=Path(p['plan']);j=json.loads(plan.read_text());j['method_notes']='The algorithm returns the average of a fixed input list.'
    plan.write_text(json.dumps(j))
    with patch('factory.capabilities.reproduction.ask_json',return_value={'code':'import os, json\n', 'assumptions':['synthetic test data']}):
        built=reproduction.generate(project,str(plan.relative_to(project)),provider='codex')
    assert built['status']=='GENERATED_UNEXECUTED'
    got=reproduction.evaluate(project,str(plan.relative_to(project)),sandbox_factory=lambda:DockerFixture())
    assert got['status']=='MATCHED_SYNTHETIC_OR_LOCAL_BASELINE'
    assert got['reproduction_established'] is False
    (project/'paper.md').write_text('changed')
    with pytest.raises(ValueError):reproduction._plan(project,str(plan.relative_to(project)))

def test_cross_model_referee_preserves_major_concerns(project):
    paper=project/'paper.md'
    native_concerns=[{'concern_id':'C1','title':'Claims causation',
                      'evidence_anchor_ids':['A001'],'failure_mechanism':'No randomized allocation'}]
    (project/'admitted.json').write_text(json.dumps(native_concerns))
    cycle={'engine':'beihang-referee-0.1.0','native_engine_and_core_prompt_executed':True,
           'scripted_test_only':False,'provider':'claude',
           'rounds':[{'input':str(paper),'sha256':common.digest(paper),
                      'concerns_file':str(project/'admitted.json')}]}
    (project/'cycle.json').write_text(json.dumps(cycle))
    norm=referee.normalize_beihang(project,'cycle.json')
    review_json=str(Path(norm['path']).relative_to(project))
    with patch('factory.capabilities.referee.ask_json',return_value={'concerns':[{'id':'C1','verdict':'SUPPORTED','reason':'no randomized allocation','needed_evidence':'causal design'}]}):
        result=referee.verify(project,'paper.md',review_json,reviewer='claude',verifier='codex')
    assert result['concerns'][0]['closure_status']=='OPEN'
    (project/'revision.md').write_text('This is a revised paper.')
    closure=referee.closure(project,str(Path(result['receipt']).relative_to(project)),'revision.md')
    assert closure['concerns'][0]['status']=='OPEN_RECHECK_REQUIRED'
    with pytest.raises(ValueError):referee.verify(project,'paper.md',review_json,reviewer='codex',verifier='codex')
    bad=json.loads(Path(norm['path']).read_text())
    bad['source']='manually-forged'
    Path(norm['path']).write_text(json.dumps(bad))
    with pytest.raises(ValueError):referee.verify(project,'paper.md',review_json,reviewer='claude',verifier='codex')


def test_paper2agent_golden_and_permission(project):
    (project/'tool.py').write_text('def run(payload): return {"value": payload["x"] * 2}\n')
    (project/'golden.json').write_text(json.dumps([{'input':{'x':2},'expected':{'value':4}}]))
    with pytest.raises(ValueError):publishing.build(project,'tool.py','golden.json',name='toy')
    fake=DockerFixture(metrics=[{'value':4}])
    out=publishing.build(project,'tool.py','golden.json',name='toy',approve=True,sandbox_factory=lambda:fake)
    assert out['golden_passed'] and out['scientific_claims_verified'] is False
    assert (project/'published_agents'/'toy'/'skill'/'mcp_server.py').exists()
    assert (project/'published_agents'/'toy'/'skill'/'SKILL.md').is_file()
    with pytest.raises(ValueError):publishing.build(project,'tool.py','golden.json',name='toy',approve=True,sandbox_factory=lambda:fake)

def test_cli_help_compatibility(capsys):
    with pytest.raises(SystemExit) as ex:
        main(['--help'])
    output=capsys.readouterr().out
    assert ex.value.code==0
    for term in ['run','resume','idea-discovery','referee','skills','autoresearch','reproduce-paper','memory','paper2agent']:
        assert term in output

def test_read_only_workflow_dashboard(project):
    from factory.capabilities.workflow import inspect
    result=inspect(project,Path(__file__).resolve().parents[1]/'skills')
    assert result['legacy_stages_unchanged'] is True
    assert result['status']=='ENGINEERING_STATUS_NOT_SCIENTIFIC_CERTIFICATION'
    assert 'autoresearch' in result['capabilities']


def test_normalize_real_beihang_contract(project):
    manuscript=project/'paper.md'
    admitted=[{'concern_id':'BH1','title':'Baseline is untested','evidence_anchor_ids':['E10'],
               'failure_mechanism':'No direct comparator'}]
    concerns=project/'admitted.json'
    concerns.write_text(json.dumps(admitted))
    cycle={'engine':'beihang-referee-0.1.0','native_engine_and_core_prompt_executed':True,
           'scripted_test_only':False,'provider':'claude',
           'rounds':[{'input':str(manuscript),'sha256':common.digest(manuscript),'concerns_file':str(concerns)}]}
    (project/'cycle.json').write_text(json.dumps(cycle))
    result=referee.normalize_beihang(project,'cycle.json')
    assert result['concerns']==1
    data=json.loads(Path(result['path']).read_text())
    assert data['concerns'][0]['id']=='BH1'
    assert data['anchor_verification']=='UNVERIFIED_ID_REFERENCES'
    with pytest.raises(ValueError):referee.normalize_beihang(project,'cycle.json')


def test_actual_cli_status_and_memory(project, tmp_path, monkeypatch, capsys):
    import factory.cli.main as cli
    import importlib
    cli=importlib.import_module('factory.cli.main')
    monkeypatch.setattr(cli,'WORKSPACES',tmp_path)
    folder=tmp_path/'my-project';folder.mkdir()
    (folder/'evidence.json').write_text('{"status":"synthetic"}')
    assert cli.main(['memory','add','my-project','--topic','pilot','--lesson','failed baseline',
                     '--evidence','evidence.json'])==0
    capsys.readouterr()
    assert cli.main(['memory','query','my-project','--term','baseline','--all'])==0
    got=json.loads(capsys.readouterr().out)
    assert got['scope']=='THIS_PROJECT_ONLY' and len(got['lessons'])==1
    assert cli.main(['workflow','status','my-project'])==0
    result=json.loads(capsys.readouterr().out)
    assert result['legacy_stages_unchanged'] is True


def test_experiment_requires_valid_candidate_and_no_fake_live_provider(project):
    contract={'editable_files':['model.py'],'frozen_files':['evaluation.py'],
              'metric':'score','direction':'max','baseline':0.50,
              'command':['python','evaluation.py'],'max_trials':1}
    (project/'contract.json').write_text(json.dumps(contract))
    with pytest.raises(ValueError):experiments.run(project,'contract.json',proposals=[])
    (project/'contract.json').write_text(json.dumps(contract))
    fake=DockerFixture(metrics={'score':0.8})
    result=experiments.run(project,'contract.json',provider='codex',
                           proposals=[{'file':'model.py','content':'x=2'}],sandbox_factory=lambda:fake)
    assert result['model_cli_executed'] is False
    assert result['provider'] is None
    assert result['proposal_source']=='operator-fixtures'
    assert result['baseline_independently_verified'] is False


def test_paper2agent_never_publishes_failed_golden(project):
    (project/'tool.py').write_text('def run(payload): return None\n')
    (project/'golden.json').write_text(json.dumps([{'input':{'x':2},'expected':4}]))
    res=publishing.build(project,'tool.py','golden.json',name='incorrect-tool',approve=True,
                         sandbox_factory=lambda:DockerFixture(metrics=[None]))
    assert res['status']=='BLOCKED_GOLDEN_TEST_FAILED'
    assert not (project/'published_agents'/'incorrect-tool'/'skill').exists()


def test_reproduce_requires_explicit_method_notes(project):
    result=reproduction.scaffold(project,'paper.md')
    with pytest.raises(ValueError):reproduction.generate(project,
       str(Path(result['plan']).relative_to(project)),provider='codex')
