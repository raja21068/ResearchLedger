# ResearchLedger v3 — six optional scientific capabilities

These optional modules **do not alter** legacy S1–S5, Idea Discovery V5 phases 10–19, Beihang Referee core/full prompts, PaperOrchestra source or ResearchLedger's evidence statuses. They are staged engineering functions, **not** claims of journal-level research validation. No API key is needed in the project: log into `claude` or `codex` locally for model-backed operations. Docker must be installed for code execution.

## Commands

```bash
researchctl skills list
researchctl skills show --name paper-to-code
researchctl autoresearch PROJECT --contract experiment_contract.json --provider codex
researchctl reproduce-paper scaffold PROJECT --paper paper.md --expected-metric 0.75 --tolerance 0.01
# Edit reproduction/paper-<digest>/plan.json and complete all method details
researchctl reproduce-paper generate PROJECT --plan reproduction/paper-<digest>/plan.json --provider codex
researchctl reproduce-paper run PROJECT --plan reproduction/paper-<digest>/plan.json
researchctl memory add PROJECT --topic "failed baseline" --lesson "loss of reproducibility" --evidence experiments/exp1/summary.json
researchctl memory query PROJECT --term "baseline" --all
researchctl memory promote PROJECT --id LESSON_ID --state OBSERVED --approve
researchctl referee cycle PROJECT manuscript.pdf --provider claude --pipeline full --mode deep
# Review output needs a normalized concern JSON with the manuscript SHA-256, provider and stable IDs.
researchctl referee dual-review PROJECT paper.md review.json --reviewer claude --verifier codex
researchctl referee closure-check PROJECT prior_receipt.json revised.md --evidence experiments/exp1/summary.json
researchctl paper2agent PROJECT --code tools/my_method.py --golden tests/my_method_golden.json --name my-method --approve
```

### Autoresearch contract (`experiment_contract.json`, project-relative)

```json
{
 "editable_files": ["model.py"], "frozen_files": ["evaluation.py"],
 "command": ["python", "evaluation.py"],
 "metric": "score", "direction": "max", "baseline": 0.50,
 "min_delta": 0.01, "max_trials": 3, "timeout": 600
}
```

The baseline should come from an actual measured, inspectable run. The evaluator cannot be edited by the optimizer but still requires independent human inspection to rule out result gaming. Every attempt is retained; original code is not overwritten. Report statuses are `KEPT`, `REVERTED`, or `FAILED`; all receipts explicitly deny independent scientific verification. In offline tests, operator-supplied proposal fixtures are allowed via `--proposals project-relative.json`; these **do not** constitute model inference.

### Paper2Code

The original paper is hashed and must stay unchanged. The scientist/operator reviews extracted methods and resolves assumptions before invoking Claude Code or Codex. The generated `reproduce.py` runs only through network-isolated Docker. Metric matching is just a **local numeric comparator**, not independent code-level reproduction or validation of a paper's scientific claims.

### Cross-model concern challenge

First run the *actual* Beihang Referee native `core/full` review using its original prompts and your added senior-review rubric. Build a structured, manuscript-digest-bound reviewer concern JSON from its admitted major concerns (stable ID, claim, anchor), then run `dual-review` through the **other** CLI model family. A second model checks whether a concern is defensible; `SUPPORTED`, `UNSUPPORTED`, and `UNCERTAIN` are not independent evidence certification. The `closure-check` deliberately retains every prior concern as open until later evidence/human assessment. It does not auto-accept model scores.

### Research memory

SQLite is only a local project-scoped index. A lesson begins at `PROPOSED`, is invisible to default qualified retrieval, and can be promoted only by explicit approval. Promotions require unchanged hashed evidence. `OBSERVED` means the operator observed the local outcome; `REPLICATED` must be used only with appropriate independent evidence. SQLite data are not uploaded automatically or shared between projects.

### Scientific skill registry

`skills list` inspects each local `SKILL.md`, discovers optional version strings and computes a digest of the complete skill folder. Discovery never executes arbitrary skill scripts or silently imports external repos. For third-party skills, assess license, trust tier, data exposure, dependencies and compatibility before manual installation.

### Paper2Agent export

Build a `tool.py` defining `run(payload)` and independently authored golden fixtures with `[ {"input":..., "expected":...} ]` under the same project. The publisher runs all cases in restricted Docker; only exact-output matches produce a distributable `skill/` with source, provenance and an **optional, untested-at-runtime MCP wrapper** (requires the official `mcp` library). Human approval and real-method validation remain separate requirements. Do not auto-deploy packages.

### Work that still needs full integration

This release delivers the six **opt-in execution surfaces** with offline contract tests. It does not claim that all six are automatically connected to Factory S1–S5 or that an end-to-end live Claude/Codex research project was executed. The next engineering milestone is a DAG workflow controller with reliable resume, independently measured baselines, expert-reviewed concern closure, and a real PaperBench-style evaluation. No vendor prompt files were altered.

### Read-only integration status

`researchctl workflow status PROJECT [--idea-id IDEA-001]` inspects existing capability receipts and, optionally, V5 phase 10–16 artifacts without performing model work, advancing paper stages or incorrectly certifying novelty. It is an initial integration dashboard, **not yet an automatic research DAG runner**. Where V5 phases 17–19 require actual minimum viable experiments, their evidence must remain separately evaluated.

A Beihang `referee cycle` execution writes a `review_cycle_<hash>.json` manifest. Run `researchctl referee normalize-beihang PROJECT beihang_referee/review_cycle_<hash>.json` to convert native admitted concerns into a digest-bound cross-model verification input. The normalization does **not** resolve page/line anchors or certify criticisms.
