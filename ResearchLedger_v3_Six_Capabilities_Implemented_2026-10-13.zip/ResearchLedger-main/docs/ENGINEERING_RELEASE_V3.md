# Engineering release — ResearchLedger six capability preview

**Build date:** 2026-10-13  
**Base source archive:** `ResearchLedger_PaperOrchestra_Skills_Integrated_2026-10-13.zip`  
**Source scope:** first-party opt-in modules, six skills, CLI, CI and documentation. All upstream `vendor/` code is preserved byte-for-byte.

## Implemented

1. `factory/capabilities/experiments.py`: deterministic candidate scratch trees, frozen evaluators, bounded Claude/Codex code-proposal JSON, restricted Docker scoring, candidate keep/revert decisions, per-trial metadata and sealed capability receipt. Operator-supplied patches are labeled **operator fixtures**, not model inference. The baseline numeric score must be reviewed; a protocol check applies in validation mode.
2. `factory/capabilities/reproduction.py`: paper digest, operator-reviewed method/assumptions plan, Claude/Codex single-script code generation, Docker evaluation and guarded local numeric comparison. This is a *Paper2Code-inspired new mode*, not the imported Paper2Code reference implementation and not a reproduction benchmark result.
3. `factory/capabilities/referee.py`: native Beihang last-round concern normalization with digest checks; independent provider-family challenge via Claude/Codex; persistent concern IDs and no silent closure. A model `SUPPORTED` verdict is not independent scientific verification. Preserve original Beihang `core/full` flow and trusted senior rubric.
4. `factory/capabilities/memory.py`: a separate project-local SQLite memory index, hashed source evidence, explicit proposed/observed/replicated states, promotion requiring operator approval, queries that hide unqualified or mutated lessons by default.
5. `factory/capabilities/skills.py`: discovery of existing and new scientific `SKILL.md` folders, optional version metadata, deterministic SHA-256 of the entire skill directory and digest pins, symlink traversal rejection, no automatic skill execution.
6. `factory/capabilities/publishing.py`: operator-approved code+golden-fixture export tested via existing restricted Docker sandbox, exported Agent Skill/provenance, optional reference MCP wrapper that requires the `mcp` package. No auto-publishing or scientific certification.

Read-only `researchctl workflow status PROJECT` collects valid capability receipts. The original S1–S5 stage orchestrator remains unchanged, and this **is not yet an autonomous DAG executing all six in one call**.

## Verified test evidence

- Focused compatibility group, executed after last README update: **123 passed**, pytest exit status 0 (`tests/test_six_capabilities_v3.py`, `test_beihang_upgrade.py`, `test_pipeline.py`, `test_steps.py`, `test_results.py`, `test_science_v2.py`).
- The six-capability test file independently: **14 passed**, including adversarial / negative tests.
- A separate targeted CLI/native-agent group: **59 passed** earlier in implementation (before minor subsequent changes); later targeted groups also passed.
- The full `tests/` and `tests_researchledger/` suites were attempted, but **timed out** before reaching completion. No full-suite pass is asserted.
- This runtime does not have `claude`, `codex` or Docker. **No actual LLM-backed V5/Referee review, no Docker execution, and no real MCP server execution were performed.** External scientific validity is not claimed.

## Source integrity

The final release manifest gives the exact input ZIP name, new files, modified files, SHA-256 digest and archive integrity results. All **1,463 vendored source files** from the input ZIP were compared byte-for-byte, unchanged. This includes bundled Idea Discovery V5, Beihang Referee, Referee Lean v2 and PaperOrchestra. Original user-authored manuscripts and validation-study result files are unchanged.

## Non-negotiable open work

- Full primary and mirror regression runs on a host without execution timeouts; standard CI also includes the v3 tests.
- Live provider-backed Claude/Codex smoke, model authentication, realistic experiment budgets and data-governance authorization.
- Live restricted Docker baseline/reproduction/publishing runs; proof against output metric gaming, multi-seed statistics and scientifically meaningful effect-size thresholds.
- Automatic six-capability resumable workflow DAG, human-review transitions and robust failure/resume receipts. Current workflow command is **read-only status**.
- Independent scholarly full-text prior-art verification, externally adjudicated reviewer concerns, and a real paper reproduction benchmark.
- Golden-test provenance outside the same model-generated codebase, verified MCP implementation and license/dependency validation before public publishing.

**Evidence principle:** Passing a software test cannot turn a generated research claim into an independently verified scientific fact. Automated `checked`, human `observed`, and actual external replication must remain distinct.
